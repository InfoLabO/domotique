
#ifndef _PCM_DRV_H
#define _PCM_DRV_H


extern const drv_t pcm_drv_sd;


#endif /* _PCM_DRV_H */
