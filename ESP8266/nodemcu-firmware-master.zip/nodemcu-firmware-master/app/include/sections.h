#ifndef _SECTIONS_H_
#define _SECTIONS_H_

#define TEXT_SECTION_ATTR __attribute__((section(".text")))

#endif
