// Common platform functions

#ifndef __COMMON_H__
#define __COMMON_H__

#include "platform.h"

// Functions exported by the common platform layer
void cmn_platform_init(void);

// Timer-specific functions

// System timer generic implemenation

// Filesystem-related functions

#endif // #ifndef __COMMON_H__

